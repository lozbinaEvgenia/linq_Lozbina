﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace linqlinq
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Person> people = new List<Person>();
            string file = "1.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("файл не найден", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] s = File.ReadAllLines(file);
                Person p1 = new Person("", "", "", 0, 0);
                foreach (string ss in s)
                {
                    string[] peopl = ss.Split(' ');
                    string fam = peopl[0];
                    p1.set_lastname(fam);
                    string name = peopl[1];
                    p1.set_name(name);
                    string ot = peopl[2];
                    p1.set_otfather(ot);
                    int age = Convert.ToInt32(peopl[3]);
                    p1.set_age(age);
                    double weith = Convert.ToDouble(peopl[4]);
                    p1.set_weidth(weith);
                    listBox1.Items.Add($"{p1.get_lastname()} {p1.get_name()} {p1.get_otfather()} {p1.get_age()} {p1.get_weidth()}");
                    people.Add(new Person(fam, name, ot, age, weith));
                }
                var yung = from p in people
                            where Convert.ToInt32(p.get_age()) < 40
                            select p;

                foreach (var y in yung)
                {
                    listBox2.Items.Add($"{y.get_lastname()} {y.get_name()} {y.get_otfather()}, Возраст: {y.get_age()} лет, Вес: {y.get_weidth()} кг");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<Department> department = new List<Department>()
            {
                new Department { Name = "Отдел закупок", Reg ="Германия" },
                new Department { Name = "Отдел продаж", Reg ="Испания" },
                new Department { Name = "Отдел маркетинга", Reg ="Испания" }
            };

            List<Employ> employes = new List<Employ>()
            {
             new Employ {Name="Иванов", department ="Отдел закупок"},
             new Employ {Name="Петров", department ="Отдел закупок"},
             new Employ {Name="Сидоров", department ="Отдел продаж"},
             new Employ {Name="Лямин", department ="Отдел продаж"},
             new Employ {Name="Сидоренко", department ="Отдел маркетинга"},
             new Employ {Name="Кривоносов", department ="Отдел продаж"}

            };
            var group = from a in employes
                          join b in department on a.department equals b.Name
                          select new { name = a.Name, dep = a.department, reg = b.Reg };
            foreach (var c in group)
                listBox3.Items.Add($"{c.name} - {c.dep}. Регион: {c.reg}");

            listBox4.Items.Add("Испания:");
            var ii = from a in department
                     join b in employes on a.Name equals b.department
                     where a.Reg.StartsWith("И")
                     select b.Name;
            foreach (var c in ii)
                listBox4.Items.Add(c);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
